
Credit to soldoestech, madpro25, and christitustech for ideas and config pieces
