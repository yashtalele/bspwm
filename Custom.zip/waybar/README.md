![waybar](https://ik.imagekit.io/rayshold/dotfiles/_config/hypr/wayabr.webp?updatedAt=1680639074588)

**Note**

scripts/waybar.sh : Hot reload waybar during configuration
